# FastReply Web

고객 상담 자동화 플랫폼 **FastReply**의 Next.js 프론트엔드.

## 실행 방법

```bash
npm install
npm run dev
```

## 배포

- Vercel에 연결 → `fastreply.kr` 또는 `fastreply.com` 도메인 매핑
- 환경변수에 Stripe / 카카오페이 / 토스 키 입력
