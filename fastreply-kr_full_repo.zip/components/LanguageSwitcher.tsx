'use client'
import { usePathname } from 'next/navigation';
export default function LanguageSwitcher(){
  const p = usePathname()||'/ko';
  const alt = p.startsWith('/en')? p.replace('/en','/ko'): p.replace('/ko','/en');
  const txt = p.startsWith('/en')? '한국어':'English';
  return <a className="underline text-sm" href={alt}>{txt}</a>;
}