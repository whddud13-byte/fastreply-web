'use client'
import React,{useState} from 'react';
export default function ChatWidget(){
  const [msgs,setMsgs]=useState([{role:'bot',text:'안녕하세요! 무엇을 도와드릴까요?'}] as any);
  const [q,setQ]=useState('');
  const send=async()=>{const t=q.trim(); if(!t)return; setMsgs((m:any)=>[...m,{role:'user',text:t}]); setQ(''); const r=await fetch('/api/chat',{method:'POST',body:JSON.stringify({message:t})}); const {reply}=await r.json(); setMsgs((m:any)=>[...m,{role:'bot',text:reply}]);};
  return <div className="fixed bottom-5 right-5 w-80 rounded-2xl border bg-white shadow-xl">
    <div className="border-b px-4 py-2 font-semibold">Chat</div>
    <div className="h-72 p-3 overflow-auto space-y-2">{msgs.map((m:any,i:number)=>(<div key={i} className={\`rounded-xl px-3 py-2 text-sm \${m.role==='user'?'ml-auto bg-black text-white max-w-[75%]':'bg-gray-100 max-w-[85%]'}\`}>{m.text}</div>))}</div>
    <div className="flex gap-2 p-3"><input className="flex-1 rounded-xl border px-3 py-2" value={q} onChange={e=>setQ(e.target.value)} placeholder="Message" onKeyDown={e=>e.key==='Enter'&&send()}/><button onClick={send} className="rounded-xl bg-black text-white px-3 py-2">Send</button></div>
  </div>;
}