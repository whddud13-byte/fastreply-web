'use client'
import { useEffect, useState } from 'react';
export default function CookieConsent(){
  const [hide,setHide]=useState(true);
  useEffect(()=>{ setHide(localStorage.getItem('cookie_ok')==='1'); },[]);
  if(hide) return null;
  return <div className="fixed bottom-0 inset-x-0 bg-black text-white text-sm z-50">
    <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-3">
      <span>본 사이트는 서비스 제공을 위해 최소한의 쿠키만 사용합니다.</span>
      <div className="flex gap-2">
        <button onClick={()=>{localStorage.setItem('cookie_ok','1');setHide(true);}} className="bg-white text-black px-3 py-1 rounded-md">동의</button>
        <a href="/ko/(legal)/privacy" className="underline">자세히</a>
      </div>
    </div>
  </div>;
}