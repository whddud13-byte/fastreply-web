export default { reactStrictMode:true }
