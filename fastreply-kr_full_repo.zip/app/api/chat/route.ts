import { NextRequest, NextResponse } from "next/server";
const RULES=[{k:["가격","요금","비용","price"],a:"요금은 Starter/Pro 두 구간입니다. 요금제 참고하세요."},
{k:["환불","취소","refund"],a:"구축비는 환불 불가, 구독은 미사용분 일할 환불합니다."},
{k:["상담","문의","데모","contact","demo"],a:"연락처 남겨주시면 24시간 내 안내드립니다."}];
function rule(q:string){const s=(q||"").toLowerCase(); for(const r of RULES) if(r.k.some(x=>s.includes(x))) return r.a; return "문의 감사합니다! 간단 질문은 지금 답하고, 자세한 건 데모 일정을 잡아드릴게요.";}
export async function POST(req:NextRequest){const {message}=await req.json(); return NextResponse.json({reply:rule(message)});}