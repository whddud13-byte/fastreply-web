'use client'
import ChatWidget from '@/components/ChatWidget';
export default function Page(){
  return (<main className="p-10">
    <h1 className="text-4xl font-bold">⚡ 24시간 3초 응답 AI 상담 - FastReply</h1>
    <p className="mt-4 text-gray-600">웹/카톡/인스타 DM 자동응답, 복잡한 건 상담원 핸드오버.</p>
    <p className="mt-2 text-xs text-gray-500">국내: 토스/카카오 • 해외: Stripe/PayPal</p>
    <ChatWidget/>
  </main>)
}