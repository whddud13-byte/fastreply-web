'use client'
import ChatWidget from '@/components/ChatWidget';
export default function Page(){
  return (<main className="p-10">
    <h1 className="text-4xl font-bold">⚡ 3-second replies, 24/7 - FastReply</h1>
    <p className="mt-4 text-gray-600">Automate web/Kakao/Instagram DM, hand over complex issues to agents.</p>
    <p className="mt-2 text-xs text-gray-500">KR: Toss/Kakao • Global: Stripe/PayPal</p>
    <ChatWidget/>
  </main>)
}